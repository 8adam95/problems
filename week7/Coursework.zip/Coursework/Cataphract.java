public class Cataphract extends Soldier
{
	public Cataphract(String name, double speed, double posX, double posY)
	{
		super(name, speed, posX, posY);
	}
}