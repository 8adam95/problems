public class Arbalist extends Soldier
{
	private double range;

	public Arbalist(String name, double speed, double posX, double posY, double range)
	{
		super(name, speed, posX, posY);
		this.range = range;
	}

	public double getRange()
	{
		return range;
	}


}