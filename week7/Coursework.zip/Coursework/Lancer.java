public class Lancer extends Soldier
{
	public Lancer(String name, double speed, double posX, double posY)
	{
		super(name, speed, posX, posY);
	}

}