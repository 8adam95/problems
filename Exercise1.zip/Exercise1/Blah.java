public class Blah {
  public static void main(String args[])
  {
    System.out.println("Adam Szefer");
  }
}